import random
from datetime import date

from dateutil.relativedelta import relativedelta

from odoo import api, fields, models
from odoo.exceptions import UserError

INDONESIAN_MONTHS = {
    1: 'Januari', 2: 'Februari', 3: 'Maret', 4: 'April',
    5: 'Mei', 6: 'Juni', 7: 'Juli', 8: 'Agustus',
    9: 'September', 10: 'Oktober', 11: 'November', 12: 'Desember',
}

VENDOR_MASTER = [
    {
        'name': 'PT Krakatau Steel (Persero) Tbk',
        'street': 'Jl. Industri No. 5',
        'city': 'Cilegon',
        'phone': '(0254) 391111',
        'email': 'procurement@krakatusteel.co.id',
    },
    {
        'name': 'PT Semen Indonesia (Persero) Tbk',
        'street': 'Jl. Veteran No. 10',
        'city': 'Gresik',
        'phone': '(031) 3981732',
        'email': 'sales@semenindonesia.com',
    },
    {
        'name': 'PT United Tractors Tbk',
        'street': 'Jl. Raya Bekasi Km. 22, Cakung',
        'city': 'Jakarta Timur',
        'phone': '(021) 24579999',
        'email': 'parts@unitedtractors.com',
    },
    {
        'name': 'PT Pionirbeton Industri',
        'street': 'Jl. Raya Serpong Km. 8',
        'city': 'Tangerang Selatan',
        'phone': '(021) 53122888',
        'email': 'order@pionirbeton.co.id',
    },
    {
        'name': 'PT Pertamina Patra Niaga',
        'street': 'Jl. Yos Sudarso No. 32-34',
        'city': 'Jakarta Utara',
        'phone': '(021) 4301515',
        'email': 'industrial@patraniaga.com',
    },
]

# Profil kepribadian skor vendor — menghasilkan variasi ranking yang realistis
VENDOR_SCORE_PROFILES = [
    # Krakatau Steel: kualitas baja sangat tinggi, harga premium
    {'C1': (85, 95), 'C2': (3500, 4500), 'C3': (75, 88), 'C4': (78, 90)},
    # Semen Indonesia: performa stabil di semua aspek, harga kompetitif
    {'C1': (80, 92), 'C2': (3000, 4000), 'C3': (80, 92), 'C4': (75, 88)},
    # United Tractors: layanan after-sales unggulan, harga paling mahal
    {'C1': (78, 90), 'C2': (4000, 5000), 'C3': (82, 95), 'C4': (85, 95)},
    # Pionirbeton: delivery tercepat, kualitas standar
    {'C1': (75, 88), 'C2': (3200, 4200), 'C3': (85, 95), 'C4': (80, 90)},
    # Pertamina Patra Niaga: harga paling bersaing, layanan rata-rata
    {'C1': (78, 88), 'C2': (2800, 3800), 'C3': (78, 90), 'C4': (72, 85)},
]


class ScoringPeriodDemoGenerator(models.Model):
    _inherit = 'scoring.period'

    @api.model
    def generate_demo_data(self):
        """Entry point: generate 12 monthly evaluation periods with realistic scores."""
        existing_demo = self.search([
            ('name', 'like', 'Evaluasi Vendor - %'),
        ], limit=1)
        if existing_demo:
            raise UserError(
                "Demo data sudah pernah di-generate. "
                "Hapus periode evaluasi yang ada terlebih dahulu jika ingin generate ulang."
            )

        vendors = self._ensure_demo_vendors()
        package = self.env.ref(
            'gifari_vendor_scoring.package_default_4c',
            raise_if_not_found=False,
        )
        if not package or not package.line_ids:
            raise UserError(
                "Paket Kriteria default tidak ditemukan atau kosong. "
                "Pastikan modul terinstall dengan benar."
            )

        generated_period_ids = self._generate_monthly_periods(vendors, package)

        return {
            'type': 'ir.actions.act_window',
            'name': 'Demo Data - Periode Evaluasi',
            'res_model': 'scoring.period',
            'view_mode': 'list,form',
            'domain': [('id', 'in', generated_period_ids)],
            'target': 'current',
        }

    @api.model
    def _ensure_demo_vendors(self):
        """Find or create the 5 construction vendor partners."""
        partner_model = self.env['res.partner']
        vendor_records = partner_model
        for vendor_def in VENDOR_MASTER:
            existing = partner_model.search([
                ('name', '=', vendor_def['name']),
            ], limit=1)
            if existing:
                vendor_records |= existing
            else:
                vendor_records |= partner_model.create({
                    **vendor_def,
                    'supplier_rank': 1,
                    'company_type': 'company',
                })
        return vendor_records

    @api.model
    def _generate_monthly_periods(self, vendors, package):
        """Create 12 monthly periods, fill scores, calculate SAW, validate historical."""
        today = date.today()
        current_month_start = today.replace(day=1)
        generated_ids = []

        for month_offset in range(11, -1, -1):
            period_start = current_month_start - relativedelta(months=month_offset)
            period_end = period_start + relativedelta(months=1, days=-1)
            month_label = INDONESIAN_MONTHS[period_start.month]
            period_name = "Evaluasi Vendor - %s %d" % (month_label, period_start.year)

            period_criteria_vals = [
                (0, 0, {
                    'criterion_id': pkg_line.criterion_id.id,
                    'weight': pkg_line.weight,
                })
                for pkg_line in package.line_ids
            ]

            period = self.create({
                'name': period_name,
                'date_from': period_start,
                'date_to': period_end,
                'package_id': package.id,
                'evaluator_id': self.env.user.id,
                'state': 'draft',
                'period_criterion_ids': period_criteria_vals,
                'partner_ids': [(6, 0, vendors.ids)],
            })

            self._create_vendor_scores(period, vendors, package)
            self._calculate_saw_silent(period)

            # 11 bulan lalu → Tervalidasi, bulan ini → tetap Scoring
            if month_offset > 0:
                period.write({
                    'state': 'validated',
                    'validator_id': self.env.user.id,
                    'validation_date': fields.Datetime.from_string(
                        '%s 17:00:00' % period_end
                    ),
                })
            else:
                period.write({'state': 'scoring'})

            generated_ids.append(period.id)

        return generated_ids

    @api.model
    def _create_vendor_scores(self, period, vendors, package):
        """Create vendor.score + vendor.score.line records with randomized raw scores."""
        score_model = self.env['vendor.score']
        vendor_list = list(vendors)

        score_vals_batch = []
        for vendor_index, vendor in enumerate(vendor_list):
            profile = VENDOR_SCORE_PROFILES[vendor_index]
            score_line_vals = []
            for pkg_line in package.line_ids:
                criterion_code = pkg_line.criterion_id.code
                score_range = profile.get(criterion_code, (70, 90))
                if pkg_line.criterion_type == 'cost':
                    raw = round(random.uniform(score_range[0], score_range[1]), 2)
                else:
                    raw = float(random.randint(score_range[0], score_range[1]))
                score_line_vals.append((0, 0, {
                    'criterion_id': pkg_line.criterion_id.id,
                    'raw_score': raw,
                }))

            score_vals_batch.append({
                'period_id': period.id,
                'partner_id': vendor.id,
                'score_line_ids': score_line_vals,
            })

        score_model.create(score_vals_batch)

    @api.model
    def _calculate_saw_silent(self, period):
        """Replicate SAW calculation without sending emails or creating activities."""
        criterion_matrix = {}
        for period_criterion in period.period_criterion_ids:
            criterion_matrix[period_criterion.criterion_id.id] = {
                'type': period_criterion.criterion_type,
                'weight_decimal': period_criterion.weight_decimal,
                'raw_values': {},
            }

        for vendor_score in period.vendor_score_ids:
            for score_line in vendor_score.score_line_ids:
                criterion_matrix[score_line.criterion_id.id]['raw_values'][vendor_score.id] = score_line.raw_score

        for criterion_data in criterion_matrix.values():
            all_raw = list(criterion_data['raw_values'].values())
            criterion_data['max_raw'] = max(all_raw) if all_raw else 1
            criterion_data['min_raw'] = min(all_raw) if all_raw else 1

        for vendor_score in period.vendor_score_ids:
            for score_line in vendor_score.score_line_ids:
                crit = criterion_matrix[score_line.criterion_id.id]
                raw = score_line.raw_score
                if crit['type'] == 'benefit':
                    normalized = raw / crit['max_raw'] if crit['max_raw'] else 0
                else:
                    normalized = crit['min_raw'] / raw if raw else 0
                weighted = normalized * crit['weight_decimal']
                score_line.write({
                    'normalized_score': normalized,
                    'weighted_score': weighted,
                })

        for vendor_score in period.vendor_score_ids:
            vendor_score.write({
                'final_score': sum(vendor_score.score_line_ids.mapped('weighted_score')),
            })

        ranked_scores = period.vendor_score_ids.sorted(
            key=lambda vs: vs.final_score, reverse=True,
        )
        for ranking, vendor_score in enumerate(ranked_scores, start=1):
            vendor_score.write({
                'rank': ranking,
                'is_recommended': ranking == 1,
            })

        period.write({'state': 'calculated'})
